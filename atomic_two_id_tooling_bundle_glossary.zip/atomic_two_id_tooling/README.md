# Atomic Two-ID Governance Toolkit (Quickstart)

## Local usage

1. Install deps:
   ```sh
   pip install pyyaml jsonschema pre-commit
   ```
2. Enable hooks:
   ```sh
   pre-commit install
   ```
3. Validate atoms:
   ```sh
   make validate
   ```
4. Build index and graph:
   ```sh
   make index
   make graph
   ```
5. Find producers/consumers by need:
   ```sh
   python tools/atoms/find_by_need.py json application/json schemas/users.schema.json
   ```

Artifacts:
- `atoms.index.json` – catalog for search
- `atoms.graph.dot` / `.json` – chain visualization

Wire `.github/workflows/atoms-ci.yaml` into your repo for CI enforcement.
