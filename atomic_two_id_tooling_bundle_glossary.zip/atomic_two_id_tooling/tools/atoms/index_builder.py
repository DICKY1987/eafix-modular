
#!/usr/bin/env python
import json, sys, time
from collections import defaultdict
from _common import load_atoms
from pathlib import Path

def main():
    atoms = load_atoms()
    index = {
        "meta": {
            "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "count": len(atoms)
        },
        "atoms": [],
        "producer_map": defaultdict(list),  # by kind/mime/schema_ref
        "consumer_map": defaultdict(list)
    }
    def key_of(io):
        return "|".join([str(io.get("kind","")), str(io.get("mime","")), str(io.get("schema_ref",""))])
    for a in atoms:
        entry = {
            "atom_uid": a.get("atom_uid"),
            "atom_key": a.get("atom_key"),
            "title": a.get("title"),
            "tags": a.get("tags") or [],
            "inputs": a.get("inputs") or [],
            "outputs": a.get("outputs") or [],
            "_src": a.get("_src")
        }
        index["atoms"].append(entry)
        for o in entry["outputs"]:
            index["producer_map"][key_of(o)].append(entry["atom_uid"])
        for i in entry["inputs"]:
            index["consumer_map"][key_of(i)].append(entry["atom_uid"])

    # convert default dicts to normal dicts
    index["producer_map"] = dict(index["producer_map"])
    index["consumer_map"] = dict(index["consumer_map"])
    out_path = Path("atoms.index.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(index, f, indent=2)
    print(f"Wrote {out_path.resolve()}")

if __name__ == "__main__":
    main()
