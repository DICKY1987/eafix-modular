
#!/usr/bin/env python
from collections import Counter
from _common import load_atoms, ulid_like, die

def main():
    atoms = load_atoms()
    uids = [a.get("atom_uid") for a in atoms]
    bad = [u for u in uids if not ulid_like(u)]
    if bad:
        die("Invalid atom_uid format detected:\n" + "\n".join(f"- {b}" for b in bad))
    dupes = [u for u,c in Counter(uids).items() if c>1]
    if dupes:
        where = {}
        for a in atoms:
            if a.get("atom_uid") in dupes:
                where.setdefault(a["atom_uid"], []).append(a.get("_src"))
        details = "\n".join(f"- {u}: {', '.join(where[u])}" for u in dupes)
        die("Duplicate atom_uid(s) found:\n" + details)
    print("OK: unique atom_uid set.")

if __name__ == "__main__":
    main()
