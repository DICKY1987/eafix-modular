
#!/usr/bin/env python
import json
from pathlib import Path
from _common import load_atoms

def main():
    atoms = load_atoms()
    # Build edges: dep edges + output->input compatibility inferred through deps
    nodes = {a["atom_uid"]: a for a in atoms}
    edges = []
    for a in atoms:
        for d in (a.get("deps") or []):
            if d in nodes:
                edges.append((d, a["atom_uid"]))  # d -> a

    # DOT
    lines = ["digraph ATOMS {", '  rankdir=LR;']
    for uid, a in nodes.items():
        label = a.get("atom_key", uid).replace('"','\\"')
        lines.append(f'  "{uid}" [label="{label}"];')
    for u,v in edges:
        lines.append(f'  "{u}" -> "{v}";')
    lines.append("}")
    Path("atoms.graph.dot").write_text("\n".join(lines), encoding="utf-8")
    Path("atoms.graph.json").write_text(json.dumps({"nodes": list(nodes.keys()), "edges": edges}, indent=2), encoding="utf-8")
    print("Wrote atoms.graph.dot and atoms.graph.json")

if __name__ == "__main__":
    main()
