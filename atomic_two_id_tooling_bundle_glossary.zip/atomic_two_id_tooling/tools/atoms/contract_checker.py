
#!/usr/bin/env python
import os, re, fnmatch, json
from urllib.parse import urlparse
from pathlib import Path
from _common import load_atoms, die

def mime_match(p, c):
    # accepts wildcard like application/* or */json
    if not p or not c:
        return True
    if p == c:
        return True
    p_main, p_sub = p.split('/', 1) if '/' in p else (p, '*')
    c_main, c_sub = c.split('/', 1) if '/' in c else (c, '*')
    return (p_main in ('*', c_main)) and (p_sub in ('*', c_sub))

def semver_major(v):
    if not v: return None
    try:
        return int(str(v).split('.')[0])
    except Exception:
        return None

def schema_compatible(prod, need):
    # prefer exact schema_ref match; allow same $id with same MAJOR version
    pr, nr = prod.get("schema_ref"), need.get("schema_ref")
    pv, nv = prod.get("schema_version"), need.get("schema_version")
    if nr and pr:
        if nr == pr:
            # if version specified, require same MAJOR
            if nv and pv:
                return semver_major(nv) == semver_major(pv)
            return True
        # allow same basename/id with MAJOR match
        if Path(str(nr)).name == Path(str(pr)).name:
            if nv and pv:
                return semver_major(nv) == semver_major(pv)
    # if consumer didn't specify schema, accept
    return not nr

def codec_compatible(prod, need):
    # exact or consumer accepts 'none' means no transform required
    return (not need.get("codec")) or (need.get("codec") == prod.get("codec"))

def cardinality_ok(prod, need):
    # producer 'many' can satisfy consumer 'one' only if consumer allows min_items>=1
    p = prod.get("cardinality","one")
    c = need.get("cardinality","one")
    if c == "one":
        return True  # assume a single item can be selected from many
    if c == "many":
        # producer one can feed many if consumer max_items==1? typically NO -> require many
        return p == "many"
    return True

def pattern_overlap(opat, ipat):
    if not ipat or not opat:
        return True
    # coarse: if either pattern equals or one is directory superset
    o_dir = str(opat).split('*')[0]
    i_dir = str(ipat).split('*')[0]
    return o_dir.startswith(i_dir) or i_dir.startswith(o_dir)

def compatible(out, inn):
    if out.get("kind") != inn.get("kind"):
        return False
    if not mime_match(out.get("mime"), inn.get("mime")):
        return False
    if not schema_compatible(out, inn):
        return False
    if not codec_compatible(out, inn):
        return False
    if not cardinality_ok(out, inn):
        return False
    if not pattern_overlap(out.get("pattern"), inn.get("pattern")):
        return False
    return True

def main():
    atoms = load_atoms()
    uid2atom = {a.get("atom_uid"): a for a in atoms}

    # Build producers list
    producers = []
    for a in atoms:
        for o in (a.get("outputs") or []):
            producers.append((a, o))

    errors = []
    for a in atoms:
        needs = a.get("inputs") or []
        if not needs:
            continue
        declared = set(a.get("deps") or [])
        for inn in needs:
            # candidates among all producers that are also declared deps (strict)
            cands = []
            for p_atom, out in producers:
                if p_atom.get("atom_uid") in declared and compatible(out, inn):
                    cands.append(p_atom.get("atom_uid"))
            if not cands:
                errors.append(f"{a.get('_src')} needs {inn.get('name')} but no compatible producer found among declared deps {list(declared)}.")
    if errors:
        die("I/O contract compatibility failed:\n" + "\n".join("- "+e for e in errors))

    print("OK: I/O contracts are compatible for declared chains.")

if __name__ == "__main__":
    main()
