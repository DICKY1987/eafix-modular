
#!/usr/bin/env python
import sys, yaml, json, re
from pathlib import Path
from _common import load_atoms, die

def semver_major(v):
    if not v: return None
    try:
        return int(str(v).split('.')[0])
    except Exception:
        return None

def main():
    repo = Path(__file__).resolve().parents[2]
    gpath = repo / "docs" / "glossary.yaml"
    if not gpath.exists():
        die("Glossary not found at docs/glossary.yaml")
    glossary = yaml.safe_load(gpath.read_text(encoding="utf-8"))
    enums = glossary.get("enums", {})
    syn = glossary.get("synonyms", {})
    deprecated = glossary.get("deprecated_terms", {})
    schema_reg = glossary.get("schema_registry", {})
    mime_aliases = glossary.get("mime_aliases", {})

    errors = []

    def canonicalize(val, table):
        if val is None: return val
        return table.get(str(val), val)

    def check_enum(field, value, allowed, syn_table=None, path=""):
        if value is None:
            return value, []
        v = str(value)
        msgs = []
        if syn_table:
            v2 = canonicalize(v, syn_table)
            if v2 != v:
                v = v2
        if v not in allowed:
            msgs.append(f"{path}{field}='{value}' not in allowed {allowed}")
        return v, msgs

    atoms = load_atoms()
    for a in atoms:
        src = a.get("_src", "<unknown>")
        # status
        if "status" in a:
            canon, msg = check_enum("status", a["status"], enums.get("status", []), syn.get("statuses", {}), f"{src}: ")
            errors += msg
        # inputs / outputs checks
        for group_name in ("inputs","outputs"):
            ios = a.get(group_name) or []
            for i, io in enumerate(ios):
                base = f"{src}: {group_name}[{i}] "
                # kind
                kind, msg = check_enum("kind", io.get("kind"), enums.get("kind", []), syn.get("kinds", {}), base)
                errors += msg
                # role
                if "role" in io:
                    _, msg = check_enum("role", io.get("role"), enums.get("role", []), syn.get("roles", {}), base)
                    errors += msg
                # codec
                if "codec" in io:
                    _, msg = check_enum("codec", io.get("codec"), enums.get("codec", []), syn.get("codecs", {}), base)
                    errors += msg
                # cardinality
                if "cardinality" in io:
                    _, msg = check_enum("cardinality", io.get("cardinality"), enums.get("cardinality", []), syn.get("cardinalities", {}), base)
                    errors += msg
                # mime alias normalization
                if "mime" in io and io["mime"] in mime_aliases:
                    # suggest canonical MIME
                    errors.append(f"{base}mime '{io['mime']}' should be '{mime_aliases[io['mime']]}'")

                # schema registry membership & major version
                sref = io.get("schema_ref")
                sver = io.get("schema_version")
                if sref:
                    if sref not in schema_reg:
                        errors.append(f"{base}schema_ref '{sref}' not found in glossary schema_registry")
                    else:
                        majors = schema_reg[sref].get("majors_allowed", [])
                        if sver:
                            maj = semver_major(sver)
                            if maj not in majors:
                                errors.append(f"{base}schema_version '{sver}' major not allowed for {sref}; allowed={majors}")

                # deprecated terms (by kind/role/status)
                if kind in (deprecated.get("kinds") or []):
                    errors.append(f"{base}kind '{kind}' is deprecated; use a canonical alternative")

    if errors:
        die("Glossary violations found:\n" + "\n".join("- "+e for e in errors))

    print("OK: Glossary conformance passed.")

if __name__ == "__main__":
    main()
