
#!/usr/bin/env python
import json, sys
from pathlib import Path

def usage():
    print("Usage: python tools/atoms/find_by_need.py <kind> [mime] [schema_ref]", file=sys.stderr)
    sys.exit(2)

def main():
    args = sys.argv[1:]
    if not args:
        usage()
    kind = args[0]; mime = args[1] if len(args)>1 else ""; schema = args[2] if len(args)>2 else ""
    idxp = Path("atoms.index.json")
    if not idxp.exists():
        print("atoms.index.json not found. Run: python tools/atoms/index_builder.py", file=sys.stderr)
        sys.exit(1)
    idx = json.loads(idxp.read_text(encoding="utf-8"))
    key = "|".join([kind, mime, schema])
    producers = idx.get("producer_map", {}).get(key, [])
    consumers = idx.get("consumer_map", {}).get(key, [])
    print(json.dumps({"kind": kind, "mime": mime, "schema_ref": schema, "producers": producers, "consumers": consumers}, indent=2))

if __name__ == "__main__":
    main()
