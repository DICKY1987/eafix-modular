
#!/usr/bin/env python
import json, sys
from jsonschema import validate, Draft202012Validator
from _common import SCHEMA_PATH, load_atoms, die

def main():
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        schema = json.load(f)
    v = Draft202012Validator(schema)
    errors = []
    for atom in load_atoms():
        for e in v.iter_errors(atom):
            errors.append(f"{atom.get('_src')}: {e.message}")
    if errors:
        die("Schema validation failed:\n" + "\n".join("- "+e for e in errors))
    print("OK: schema validation passed for all atoms.")

if __name__ == "__main__":
    main()
