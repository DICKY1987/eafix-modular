
#!/usr/bin/env python
from _common import load_atoms, die

def main():
    atoms = load_atoms()
    uid_set = {a.get("atom_uid") for a in atoms}
    missing = []
    for a in atoms:
        for d in (a.get("deps") or []):
            if d not in uid_set:
                missing.append((a.get("_src"), d))
    if missing:
        lines = "\n".join(f"- {src}: missing dep {dep}" for src,dep in missing)
        die("Unresolved dependencies:\n" + lines)
    print("OK: all deps resolve to known atom_uids.")

if __name__ == "__main__":
    main()
