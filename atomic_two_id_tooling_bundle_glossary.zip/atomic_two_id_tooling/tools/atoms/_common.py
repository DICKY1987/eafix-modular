
import os, sys, json, re, fnmatch, yaml
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[2]
ATOMS_DIRS = [REPO_ROOT / "atoms"]
SCHEMA_PATH = REPO_ROOT / "atoms" / "schema" / "atomic_task.schema.json"

def find_atom_files():
    files = []
    for base in ATOMS_DIRS:
        if base.exists():
            for p in base.rglob("*.y*ml"):
                # avoid schema files
                if "schema" in p.parts:
                    continue
                files.append(p)
    return files

def load_atoms():
    items = []
    for p in find_atom_files():
        with open(p, "r", encoding="utf-8") as f:
            try:
                data = yaml.safe_load(f)
                if isinstance(data, dict):
                    data["_src"] = str(p.relative_to(REPO_ROOT))
                    items.append(data)
            except Exception as e:
                raise SystemExit(f"YAML parse error in {p}: {e}")
    return items

def ulid_like(s):
    # simple ULID/UUID-ish guard; not strict
    return bool(re.fullmatch(r"[0-9A-HJKMNP-TV-Z]{10,32}|[0-9a-fA-F-]{16,36}", str(s)))

def die(msg):
    print(msg, file=sys.stderr)
    sys.exit(1)
