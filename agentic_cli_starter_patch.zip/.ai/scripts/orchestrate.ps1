<#
  Orchestrates: rebase -> run tool -> (run tests) -> auto-commit -> push
  Usage example:
    pwsh -File .ai/scripts/orchestrate.ps1 -Name ui-refactor -Tool aider -Branch feat/ui-aider -Worktree ../wt-aider -Tests "pytest -q"
#>
param(
  [Parameter(Mandatory=$true)][string]$Name,
  [Parameter(Mandatory=$true)][ValidateSet("aider","cline","claude","gemini","chatgpt")]$Tool,
  [Parameter(Mandatory=$true)][string]$Branch,
  [Parameter(Mandatory=$true)][string]$Worktree,
  [string]$Tests
)

$ErrorActionPreference = "Stop"

function Run($cmd) {
  Write-Host ">> $cmd" -ForegroundColor Cyan
  iex $cmd
  if ($LASTEXITCODE -ne $null -and $LASTEXITCODE -ne 0) {
    throw "Command failed with exit code $LASTEXITCODE: $cmd"
  }
}

function Ensure-Worktree {
  param($Branch,$Worktree)
  git fetch origin | Out-Null
  $exists = & git rev-parse --verify $Branch 2>$null
  if (-not $exists) {
    Run "git worktree add `"$Worktree`" -b `"$Branch`" origin/main"
  } elseif (-not (Test-Path $Worktree)) {
    Run "git worktree add `"$Worktree`" `"$Branch`""
  }
}

Ensure-Worktree -Branch $Branch -Worktree $Worktree

Push-Location $Worktree
try {
  Run "git fetch origin --prune"
  Run "git checkout `"$Branch`""
  Run "git rebase origin/main"

  if (Test-Path .git/hooks/pre-commit -or (Get-Command pre-commit -ErrorAction SilentlyContinue)) {
    try { Run "pre-commit run -a" } catch { Write-Warning "pre-commit failed; continuing to allow the agent to attempt fixes." }
  }

  switch ($Tool) {
    "aider"  { Run "aider --yes --message 'Job:$Name run'"
               }
    "cline"  { Run "cline run --auto-approve --plan 'Job:$Name run'"
               }
    "claude" { Run "claude-code run --task 'Job:$Name run'"
               }
    "gemini" { Run "gemini run --task 'Job:$Name run'"
               }
    "chatgpt"{ Run "chatgpt-agent run --task 'Job:$Name run'"
               }
  }

  $testsOk = $true
  if ($Tests) {
    try { Run $Tests }
    catch { $testsOk = $false; Write-Warning "Tests failed for $Name" }
  }

  Run "git add -A"

  $toolTrailer = "Tool: $Tool"
  $jobTrailer  = "Job: $(Get-Date -Format s)"
  if ($testsOk) {
    Run "git commit -m 'chore($Name): auto-commit on green' -m '$toolTrailer' -m '$jobTrailer'"
  } else {
    Run "git commit -m 'chore($Name): WIP (tests failing)' -m '$toolTrailer' -m '$jobTrailer'"
  }
  Run "git push -u origin `"$Branch`""
}
finally {
  Pop-Location
}
